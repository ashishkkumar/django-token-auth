from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated  # <-- Here
import json
from django.http import HttpResponse

class HelloView(APIView):
    permission_classes = (IsAuthenticated,)             # <-- And here

    def get(self, request):
        content = {"id": 102,"message": "Lorem ipsum","created_at": "created time in UTC",
	"updated_at": "last updated time in UTC",
	"created_by": {
	"id": 3,
	"username": "testuser",
	"email": "test@mail.com",
	}
	}
        return Response(content)
#	return HttpResponse(json.dumps(content), content_type="application/json")
